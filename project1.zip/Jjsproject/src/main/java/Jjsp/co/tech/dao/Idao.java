package Jjsp.co.tech.dao;

public interface Idao {

}
