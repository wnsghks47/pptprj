package Jjsp.co.tech;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import Jjsp.co.tech.dao.Idao;
import Jjsp.co.tech.dto.MainView;


@Controller
public class HomeController {
	@Autowired
	private SqlSession sql;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {

		return "JjsTmMain";
	}
	
	@RequestMapping(value = "uploadSummerImage", method = RequestMethod.POST)
	@ResponseBody
	public Object uploadSummernoteImageFile(HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();

		String attachPath = "resources\\img\\reviewImg\\";
		String uploadPath = request.getSession().getServletContext().getRealPath("/");
		String path = uploadPath + attachPath;

		MultipartRequest multi;
		try {

			multi = new MultipartRequest(request, path, 10 * 1024 * 1024, "UTF-8", new DefaultFileRenamePolicy());

			String name = multi.getFilesystemName("file");

			String url = "resources/img/reviewImg/" + name;

			jsonObject.put("url", url);

			return jsonObject.toMap();

		} catch (IOException e) {
			e.printStackTrace();

			jsonObject.put("url", "resources/img/fail.jpg");

			return jsonObject.toMap();
		}

	}
	
	
	@RequestMapping(value = "Introduce")
	public String introduce() {
		
		return "Introduce";
	}

	@RequestMapping(value = "JjsGallery")
	public String gallery(Model model) {
		ArrayList<MainView> jmv= new ArrayList<MainView>();
		
		Idao dao = sql.getMapper(Idao.class);
		
		jmv = dao.jmvs();
		
		model.addAttribute("jms",jmv);
		
		
		return "Gallery";
	}
	
	@RequestMapping(value = "Gwrite")
	public String gwrite() {
		
		return "GalleryWrite";
	}
	@RequestMapping(value = "Gwritef")
	public String gwritef(HttpServletRequest req) {
		String jt = req.getParameter("title");
		String jw = req.getParameter("writer");
		String jc = req.getParameter("content");
		
		Idao dao= sql.getMapper(Idao.class);
		
		dao.gwrite(jt,jc,jw);
		
		return "GalleryWrite";
	}
}
