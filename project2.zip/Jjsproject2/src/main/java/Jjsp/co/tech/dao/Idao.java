package Jjsp.co.tech.dao;

public interface Idao {

	public void gwrite(String jt, String jw, String jc);

}
