package Jjsp.co.tech.dto;

public class MainView {

}
