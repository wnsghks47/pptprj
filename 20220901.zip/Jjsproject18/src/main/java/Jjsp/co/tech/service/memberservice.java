package Jjsp.co.tech.service;

import Jjsp.co.tech.dto.Memberdto;

public interface memberservice {
	
	public Memberdto login(Memberdto dto) throws Exception;

	public int checkid(String id);
	
}
