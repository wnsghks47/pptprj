package Jjsp.co.tech.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Jjsp.co.tech.dto.MainView;
import Jjsp.co.tech.dto.Memberdto;

@Repository
public class IDaolmpl implements Idao{
	
@Autowired
SqlSession sql;

@Override
public Memberdto login(Memberdto dto) {

	return sql.selectOne("Jjsp.co.tech.dao.Idao.login", dto);
}

@Override
public void gwrite(String jt, String jw, String jc) {
	// TODO Auto-generated method stub
	
}

@Override
public ArrayList<MainView> jmvs() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void gjoin(String ji, String jp, String jn) {
	// TODO Auto-generated method stub
	
}

@Override
public Memberdto jdelete(String jno) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void jdelete(Memberdto md) {
	// TODO Auto-generated method stub
	
}

@Override
public ArrayList<Memberdto> jselect() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public int checkid(String userid) {
	int result=sql.selectOne("Jjsp.co.tech.dao.IDao.checkid", userid);
	return result;
}
}
