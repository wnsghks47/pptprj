package Jjsp.co.tech.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Jjsp.co.tech.dao.Idao;
import Jjsp.co.tech.dto.Memberdto;
@Transactional
@Service
public class MemberDAOImpl implements memberservice{
	@Autowired 
	Idao dao;
	
	@Override
	public Memberdto login(Memberdto dto) throws Exception {
		
		return dao.login(dto);
	}

	@Override
	public int checkid(String userid) {
		int result=dao.checkid(userid);
		return result;
	}
}
