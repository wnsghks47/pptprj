package Jjsp.co.tech;

import java.io.IOException;
import java.util.ArrayList;

import javax.mail.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import Jjsp.co.tech.dao.Idao;
import Jjsp.co.tech.dto.MainView;
import Jjsp.co.tech.dto.Memberdto;
import Jjsp.co.tech.service.memberservice;
import Jjsp.co.tech.service.sha256;

@Controller
public class HomeController {
	
    @Autowired
    private memberservice service;
	
	@Autowired
	private SqlSession sql;
	

	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {

		return "JjsTmMain";
	}
	
	@RequestMapping(value = "uploadSummerImage", method = RequestMethod.POST)
	@ResponseBody
	public Object uploadSummernoteImageFile(HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();

		String attachPath = "resources\\img\\reviewImg\\";
		String uploadPath = request.getSession().getServletContext().getRealPath("/");
		String path = uploadPath + attachPath;

		MultipartRequest multi;
		try {

			multi = new MultipartRequest(request, path, 10 * 1024 * 1024, "UTF-8", new DefaultFileRenamePolicy());

			String name = multi.getFilesystemName("file");

			String url = "resources/img/reviewImg/" + name;

			jsonObject.put("url", url);

			return jsonObject.toMap();

		} catch (IOException e) {
			e.printStackTrace();

			jsonObject.put("url", "resources/img/fail.jpg");

			return jsonObject.toMap();
		}

	}
	
	
	@RequestMapping(value = "Introduce" )
	public String introduce() {
		
		return "Introduce";
	}

	
	@RequestMapping(value = "JjsGallery")
	public String gallery(Model model) {
		
		ArrayList<MainView> jmv= new ArrayList<MainView>();
		
		Idao dao = sql.getMapper(Idao.class);
		
		jmv = dao.jmvs();
		
		model.addAttribute("jms",jmv);
		
		
		return "Gallery";
	}
	
	@RequestMapping(value = "Gwrite")
	public String gwrite() {
		
		return "GalleryWrite";
	}
	@RequestMapping(value = "Gwritef")
	public String gwritef(HttpServletRequest req) {
		String jt = req.getParameter("title");
		String jw = req.getParameter("writer");
		String jc = req.getParameter("content");
		
		Idao dao= sql.getMapper(Idao.class);
		
		dao.gwrite(jt,jc,jw);
		
		return "GalleryWrite";
	}
	
	
	
	//login 페이지 시작
	@RequestMapping(value = "Gjoin")
	public String Gjoin() {
		
		return "join";
	}
	@RequestMapping(value = "Gjoin1" , method = RequestMethod.POST)
	public String Gjoin1(HttpServletRequest req) {
		String ji = req.getParameter("id");
		String jp1 = req.getParameter("pw1");
		String jp = sha256.encrypt(jp1);
		String jn = req.getParameter("name");
		
		Idao dao = sql.getMapper(Idao.class);
		
		dao.gjoin(ji,jp,jn);
		
		return "join";
	}
	@ResponseBody
	@RequestMapping(value = "idcheck" , method = RequestMethod.POST)
	public int idcheck(HttpServletRequest req) {
		String id = req.getParameter("id");
		
		int count = service.checkid(id);
		
		return count;
	}
	
	@RequestMapping(value = "Mypage")
	public String MyPage(HttpServletRequest request, Model model) {

		HttpSession session = request.getSession();

		Memberdto dto = (Memberdto) session.getAttribute("member");
		
		Idao dao = sql.getMapper(Idao.class);
		



		return "Mypage";
	}
	
	//사장님 페이지
	@RequestMapping(value = "ControlMst")
	public String ControlMst(HttpServletRequest request, Model model) {
		
		
		
		HttpSession session = request.getSession();

		Memberdto dto = (Memberdto) session.getAttribute("member");
		
		ArrayList<Memberdto> jlist = new ArrayList<Memberdto>();
		Idao dao = sql.getMapper(Idao.class);
		
		jlist = dao.jselect();
		
		model.addAttribute("list",jlist);



		return "ControlMst";
	}
	@RequestMapping(value = "Controldel")
	public String controldel(HttpServletRequest req, Model model, HttpSession session) {
		String jno = req.getParameter("cd");
		
		Idao dao = sql.getMapper(Idao.class);
	
		
		dao.jdelete(jno);
		
		return "redirect:ControlMst";
	}
	
	
	

	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public String login(HttpServletRequest req, Model model) 
			{
		
		HttpSession session = req.getSession();

		Memberdto dto = (Memberdto) session.getAttribute("member");
		
		Idao dao = sql.getMapper(Idao.class);
		return "Login";
	
	
	}
	@RequestMapping(value = "logingo", method = RequestMethod.POST)
	public String logingo(Memberdto dto, HttpServletRequest req, Model model) throws Exception{
		String pass = req.getParameter("userpw");
		String pw = sha256.encrypt(pass);
		dto.setUserpw(pw);
		
		HttpSession session = req.getSession();
		
		Memberdto login=service.login(dto);
		
		if (login != null) {
			session.setAttribute("member", login);
		
			
		}if (login.getMno() == 1) {
			
			return "redirect:Mypage";
			
		}else if (login.getMno() == 2) {
			
			return "redirect:ControlMst";
			
		}else if (login.getMno() ==3) {
			model.addAttribute("stop", false);
			
			return "redirect:login";
		}
		
		
		else {
			
			return "redirect:login";
			
		}
		
	
	
	}
	@RequestMapping("SearchView")
	public String SearchView(HttpSession session) {
		session.invalidate();

		return "SearchView";

	}

	
	@RequestMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();

		return "redirect:login";

	}

	}

