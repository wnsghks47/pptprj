package Jjsp.co.tech;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import Jjsp.co.tech.dao.Idao;
import Jjsp.co.tech.dto.MainView;
import Jjsp.co.tech.dto.Memberdto;
import Jjsp.co.tech.service.memberservice;
import Jjsp.co.tech.service.sha256;

@Controller
public class HomeController {
	@Autowired
	private SqlSession sql;
	
//	@Autowired
//	private memberservice member;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {

		return "JjsTmMain";
	}
	
	@RequestMapping(value = "uploadSummerImage", method = RequestMethod.POST)
	@ResponseBody
	public Object uploadSummernoteImageFile(HttpServletRequest request) {

		JSONObject jsonObject = new JSONObject();

		String attachPath = "resources\\img\\reviewImg\\";
		String uploadPath = request.getSession().getServletContext().getRealPath("/");
		String path = uploadPath + attachPath;

		MultipartRequest multi;
		try {

			multi = new MultipartRequest(request, path, 10 * 1024 * 1024, "UTF-8", new DefaultFileRenamePolicy());

			String name = multi.getFilesystemName("file");

			String url = "resources/img/reviewImg/" + name;

			jsonObject.put("url", url);

			return jsonObject.toMap();

		} catch (IOException e) {
			e.printStackTrace();

			jsonObject.put("url", "resources/img/fail.jpg");

			return jsonObject.toMap();
		}

	}
	
	
	@RequestMapping(value = "Introduce" )
	public String introduce() {
		
		return "Introduce";
	}

	@RequestMapping(value = "JjsGallery")
	public String gallery(Model model) {
		ArrayList<MainView> jmv= new ArrayList<MainView>();
		
		Idao dao = sql.getMapper(Idao.class);
		
		jmv = dao.jmvs();
		
		model.addAttribute("jms",jmv);
		
		
		return "Gallery";
	}
	
	@RequestMapping(value = "Gwrite")
	public String gwrite() {
		
		return "GalleryWrite";
	}
	@RequestMapping(value = "Gwritef")
	public String gwritef(HttpServletRequest req) {
		String jt = req.getParameter("title");
		String jw = req.getParameter("writer");
		String jc = req.getParameter("content");
		
		Idao dao= sql.getMapper(Idao.class);
		
		dao.gwrite(jt,jc,jw);
		
		return "GalleryWrite";
	}
	@RequestMapping(value = "Gjoin")
	public String Gjoin() {
		
		return "join";
	}
	@RequestMapping(value = "Gjoin1" , method = RequestMethod.POST)
	public String Gjoin1(HttpServletRequest req) {
		String ji = req.getParameter("id");
		String jp = req.getParameter("pw1");
		String jp1 = sha256.encrypt(jp);
		String jn = req.getParameter("name");
		
		Idao dao = sql.getMapper(Idao.class);
		
		dao.gjoin(ji,jp1,jn);
		
		return "join";
	}
	
//	@RequestMapping(value = "Glogin")
//	public String Glogin(HttpServletRequest req, Model model, HttpSession session, Memberdto dto) throws Exception {
//		String pass = req.getParameter("pass");
//		String pw = sha256.encrypt(pass);
//		dto.setUserpw(pw);
//		
//		Memberdto login= member.login(dto);
//		
//		if (login != null && dto.getUserpw().equals(login.getUserpw())) {
//			session.setAttribute("member", login);
//			
//			if (login.getMno() == 0) {
//				
//				return "redirect:Controlmember";
//			}
//			else if (login.getMno() == 1) {
//				
//				return "redirect:Mypage";
//			}
//			else if (login.getMno() == 2) {
//				
//				model.addAttribute("stop",false);
//				return "login";
//			}
//			else {
//				model.addAttribute("msg", false);
//				return "login";
//			}
//		}
//		else {
//			session.setAttribute("member", null);
//			model.addAttribute("msg",false);
//		}
//		return "login";
//	}
	
	@RequestMapping("logout")
	public String logout(HttpSession session) {
		session.invalidate();

		return "redirect:/";

	}
}
