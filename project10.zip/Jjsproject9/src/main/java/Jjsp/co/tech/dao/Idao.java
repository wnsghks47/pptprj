package Jjsp.co.tech.dao;

import java.util.ArrayList;

import Jjsp.co.tech.dto.MainView;
import Jjsp.co.tech.dto.Memberdto;

public interface Idao {

	public void gwrite(String jt, String jw, String jc);

	public ArrayList<MainView> jmvs();

	public void gjoin(String ji, String jp, String jn);

	public Memberdto login(Memberdto dto) throws Exception;

}
