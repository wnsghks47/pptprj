package Jjsp.co.tech.service;

public class MainView {
	private int jnum;
	private String jtitle,jimg,jwriter;
	public int getJnum() {
		return jnum;
	}
	public void setJnum(int jnum) {
		this.jnum = jnum;
	}
	public String getJtitle() {
		return jtitle;
	}
	public void setJtitle(String jtitle) {
		this.jtitle = jtitle;
	}
	public String getJimg() {
		return jimg;
	}
	public void setJimg(String jimg) {
		this.jimg = jimg;
	}
	public String getJwriter() {
		return jwriter;
	}
	public void setJwriter(String jwriter) {
		this.jwriter = jwriter;
	}

	
	
	
	


}
