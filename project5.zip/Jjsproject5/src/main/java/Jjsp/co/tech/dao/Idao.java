package Jjsp.co.tech.dao;

import java.util.ArrayList;

import Jjsp.co.tech.dto.MainView;

public interface Idao {

	public void gwrite(String jt, String jw, String jc);

	public ArrayList<MainView> jmvs();

}
