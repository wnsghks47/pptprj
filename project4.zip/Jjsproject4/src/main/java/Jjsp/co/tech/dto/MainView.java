package Jjsp.co.tech.dto;

public class MainView {
	private int jnum;
	private String jtitle,jimg,jwriter;
	private String src;
	
	
	
	public String getSrc() {
		return src;
	}
	public int getJnum() {
		return jnum;
	}
	public void setJnum(int jnum) {
		this.jnum = jnum;
	}
	public String getJtitle() {
		return jtitle;
	}
	public void setJtitle(String jtitle) {
		this.jtitle = jtitle;
	}
	public String getJimg() {
		return jimg;
	}
	public void setJimg(String jimg) {
		this.jimg = jimg;
		int srcIndex = jimg.indexOf("src");

		String src = "";

		if (srcIndex == -1) {

			src = "resources/img/wolf-background.png";

		} else {

			int startSrc = jimg.indexOf("\"", srcIndex) + 1;
			int endtSrc = jimg.indexOf("\"", startSrc);

			src = jimg.substring(startSrc, endtSrc);

		}

		this.src = src;
	}
	public String getJwriter() {
		return jwriter;
	}
	public void setJwriter(String jwriter) {
		this.jwriter = jwriter;
	}
	
}
